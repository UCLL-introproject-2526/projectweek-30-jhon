import pygame

WIDTH, HEIGHT = 800, 600
FPS = 60

DARK_BG = (30, 30, 30)
BLOCK_COLOR = (100, 100, 100)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("JHON")
clock = pygame.time.Clock()
